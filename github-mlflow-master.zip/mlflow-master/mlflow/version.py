# Copyright 2018 Databricks, Inc.


VERSION = '1.0.0.rc0'
