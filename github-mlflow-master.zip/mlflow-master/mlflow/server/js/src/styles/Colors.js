export default {
  secondaryText: "#888",
};
